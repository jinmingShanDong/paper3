import json
from transformers import AutoModelForCausalLM, AutoTokenizer
import os
import logging


os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
device = "cuda" # the device to load the model onto
def load_json(filename):
    with open(filename, "r") as f:
        return json.load(f)

model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen1.5-MoE-A2.7B-Chat-GPTQ-Int4",
    torch_dtype="auto",
    device_map="auto"
)
model = model.to(device)
tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen1.5-MoE-A2.7B-Chat-GPTQ-Int4")


prompt = "Summarize the following sentences into one sentence:"
captions = "A person is watching and explaining an amateur video of a wrestling match, featuring men competing in wrestling, fighting, and grappling on a mat, while two individuals engage in a high school wrestling match for spectators."

sentences = str(captions).replace('[','').replace(']','').replace('\'','').replace(',','.')
messages = [
{"role": "system", "content": "You are a helpful assistant."},
{"role": "user", "content": prompt+sentences}
]
text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=True
)
model_inputs = tokenizer([text], return_tensors="pt").to(device)

generated_ids = model.generate(
    model_inputs.input_ids,
    max_new_tokens=45 # 75
).to(device)

generated_ids = [
    output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
]

response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
print("response: ", response)



