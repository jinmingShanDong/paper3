import torch
from torchvision import transforms
from PIL import Image
import numpy as np
from diffusers import StableDiffusionPipeline
from torch import autocast

# 加载和预处理图像
image_path = "/data/home/jinming/code2/stable_diffusion_1/assets/txt2img-convsample.png"  # 给定图像路径
original_image = Image.open(image_path).convert("RGB")
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])
original_image_tensor = transform(original_image).unsqueeze(0).to("cuda")  # [1, 3, 224, 224]

# 1. 计算图像的特征分布（每个通道的均值和标准差）
mean_per_channel = original_image_tensor.mean(dim=(0, 2, 3))
std_per_channel = original_image_tensor.std(dim=(0, 2, 3))
print("每个通道的均值：", mean_per_channel.shape)
print("每个通道的标准差：", std_per_channel.shape)

# 加载预训练的稳定扩散模型
pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4").to("cuda")

# 2. 生成符合原图分布的初始噪声
def generate_noise(shape, mean, std):
    noise = torch.randn(shape).to("cuda")
    noise = noise * std.view(-1, 1, 1) + mean.view(-1, 1, 1)
    return noise

# 生成的初始噪声与原始图像特征的分布相似
latents = generate_noise((1, 4, 64, 64), mean_per_channel, std_per_channel)

# 3. 使用扩散模型生成新图像
prompt = "A beautiful landscape with similar features"
with autocast("cuda"):
    generated_image = pipe(prompt, latents=latents).images[0]

# 保存生成的新图像
generated_image.save("generated_image.png")
print("生成的图像已保存到 generated_image.png")



# python scripts/mu_sigma_to_image.py





