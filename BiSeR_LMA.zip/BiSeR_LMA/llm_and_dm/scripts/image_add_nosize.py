import numpy as np
import cv2

# Function to add noise to the image based on a coefficient 'a'
def add_noise(image, a):
    noise = np.random.randn(*image.shape) * a  # Generate Gaussian noise
    noisy_image = image + noise  # Add noise to the image
    noisy_image = np.clip(noisy_image, 0, 255).astype(np.uint8)  # Clip to valid range and convert to uint8
    return noisy_image

# Main function to load the image, add noise, and save the output
def process_image_with_noise(input_image_path, save_path, noise_coefficient):
    # Load the original image
    image = cv2.imread(input_image_path)
    
    if image is None:
        raise ValueError("Image not found or unable to load.")
    
    # Add noise to the image
    noisy_image = add_noise(image, noise_coefficient)
    
    save_path = save_path + str(noise_coefficient) + '.png'
    # Save the noisy image
    cv2.imwrite(save_path, noisy_image)
    return save_path

# Example usage
input_image_path = '/data/home/jinming/code2/stable_diffusion_1/scripts/add_noise_image/WechatIMG783.png'  # Replace with the actual input image path
save_path = '/data/home/jinming/code2/stable_diffusion_1/scripts/add_noise_image/'  # Specify where to save the noisy image
noise_coefficient = 100  # Adjust this coefficient to control noise level

# Process the image and save it
output_file_path = process_image_with_noise(input_image_path, save_path, noise_coefficient)

