import cv2
import numpy as np
import os

# 打开视频文件
video_path = '/data/home/jinming/code2/stable_diffusion_1/scripts/generated_images/0001_American_Beauty_00.02.15.041-00.02.16.217.avi'
output_dir = '/data/home/jinming/code2/stable_diffusion_1/scripts/generated_images/sampled_video_frames'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 读取视频
cap = cv2.VideoCapture(video_path)
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))  # 获取视频总帧数
fps = int(cap.get(cv2.CAP_PROP_FPS))  # 获取视频的帧率
duration = total_frames / fps  # 视频总时长

# 计算均匀抽帧的间隔
frame_indices = np.linspace(0, total_frames - 1, 12, dtype=int)

# 抽取帧并保存
frame_count = 0
for i, frame_idx in enumerate(frame_indices):
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)  # 设置视频读取到特定帧
    ret, frame = cap.read()
    if ret:
        # 调整图片大小为255x255
        resized_frame = cv2.resize(frame, (255, 255))
        # 保存帧为png文件
        frame_path = os.path.join(output_dir, f'frame_{i+1:02d}.png')
        cv2.imwrite(frame_path, resized_frame)
        frame_count += 1

cap.release()
print(f"共保存了 {frame_count} 帧到 '{output_dir}' 文件夹中。")
