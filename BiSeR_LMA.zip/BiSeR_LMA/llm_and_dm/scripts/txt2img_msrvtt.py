import sys
sys.path.append("/data/home/jinming/code2/stable_diffusion")
import argparse, os, glob
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
import cv2
import torch
import numpy as np
from omegaconf import OmegaConf
from PIL import Image
from tqdm import tqdm, trange
from imwatermark import WatermarkEncoder
from itertools import islice
from einops import rearrange
from torchvision.utils import make_grid
import time
from pytorch_lightning import seed_everything
from torch import autocast
from contextlib import contextmanager, nullcontext
import json
import pickle

# from stable_diffusion.ldm.util import instantiate_from_config
# from stable_diffusion.ldm.models.diffusion.ddim import DDIMSampler
# from stable_diffusion.ldm.models.diffusion.plms import PLMSSampler
# from stable_diffusion.ldm.models.diffusion.dpm_solver import DPMSolverSampler
from ldm.util import instantiate_from_config
from ldm.models.diffusion.ddim import DDIMSampler
from ldm.models.diffusion.plms import PLMSSampler
from ldm.models.diffusion.dpm_solver import DPMSolverSampler

from diffusers.pipelines.stable_diffusion.safety_checker import StableDiffusionSafetyChecker
from transformers import AutoFeatureExtractor

import logging
# 创建一个 logger
logger = logging.getLogger('my_logger')
logger.setLevel(logging.INFO)  # 设置日志级别

# 创建一个 file handler，用于写入日志文件
file_handler = logging.FileHandler('/data/home/jinming/code2/stable_diffusion/scripts/text_generated_image_001.log')
file_handler.setLevel(logging.INFO)  # 设置文件处理器的日志级别

# 创建一个 formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)

# 将 file handler 添加到 logger
logger.addHandler(file_handler)

# load safety model
safety_model_id = "CompVis/stable-diffusion-safety-checker"
safety_feature_extractor = AutoFeatureExtractor.from_pretrained(safety_model_id)
safety_checker = StableDiffusionSafetyChecker.from_pretrained(safety_model_id)


def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())


def numpy_to_pil(images):
    """
    Convert a numpy image or a batch of images to a PIL image.
    """
    if images.ndim == 3:
        images = images[None, ...]
    images = (images * 255).round().astype("uint8")
    pil_images = [Image.fromarray(image) for image in images]

    return pil_images


def load_model_from_config(config, ckpt, verbose=False):
    print(f"Loading model from {ckpt}")
    pl_sd = torch.load(ckpt, map_location="cpu")
    if "global_step" in pl_sd:
        print(f"Global Step: {pl_sd['global_step']}")
    sd = pl_sd["state_dict"]
    model = instantiate_from_config(config.model)
    m, u = model.load_state_dict(sd, strict=False)
    if len(m) > 0 and verbose:
        print("missing keys:")
        print(m)
    if len(u) > 0 and verbose:
        print("unexpected keys:")
        print(u)

    model.cuda()
    model.eval()
    return model


def put_watermark(img, wm_encoder=None):
    if wm_encoder is not None:
        img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        img = wm_encoder.encode(img, 'dwtDct')
        img = Image.fromarray(img[:, :, ::-1])
    return img


def load_replacement(x):
    try:
        hwc = x.shape
        y = Image.open("assets/rick.jpeg").convert("RGB").resize((hwc[1], hwc[0]))
        y = (np.array(y)/255.0).astype(x.dtype)
        assert y.shape == x.shape
        return y
    except Exception:
        return x


def check_safety(x_image):
    safety_checker_input = safety_feature_extractor(numpy_to_pil(x_image), return_tensors="pt")
    x_checked_image, has_nsfw_concept = safety_checker(images=x_image, clip_input=safety_checker_input.pixel_values)
    assert x_checked_image.shape[0] == len(has_nsfw_concept)
    for i in range(len(has_nsfw_concept)):
        if has_nsfw_concept[i]:
            x_checked_image[i] = load_replacement(x_checked_image[i])
    return x_checked_image, has_nsfw_concept


def main(class_num, path_pkl):
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--prompt",
        type=str,
        nargs="?",
        default="a painting of a virus monster playing guitar",
        help="the prompt to render"
    )
    parser.add_argument(
        "--outdir",
        type=str,
        nargs="?",
        help="dir to write results to",
        default="outputs/txt2img-samples"
    )
    parser.add_argument(
        "--skip_grid",
        action='store_true',
        help="do not save a grid, only individual samples. Helpful when evaluating lots of samples",
    )
    parser.add_argument(
        "--skip_save",
        action='store_true',
        help="do not save individual samples. For speed measurements.",
    )
    parser.add_argument(
        "--ddim_steps",
        type=int,
        default=50,
        help="number of ddim sampling steps",
    )
    parser.add_argument(
        "--plms",
        action='store_true',
        help="use plms sampling",
    )
    parser.add_argument(
        "--dpm_solver",
        action='store_true',
        help="use dpm_solver sampling",
    )
    parser.add_argument(
        "--laion400m",
        action='store_true',
        help="uses the LAION400M model",
    )
    parser.add_argument(
        "--fixed_code",
        action='store_true',
        help="if enabled, uses the same starting code across samples ",
    )
    parser.add_argument(
        "--ddim_eta",
        type=float,
        default=0.0,
        help="ddim eta (eta=0.0 corresponds to deterministic sampling",
    )
    parser.add_argument(
        "--n_iter",
        type=int,
        default=2,
        help="sample this often",
    )
    parser.add_argument(
        "--H",
        type=int,
        default=512,
        help="image height, in pixel space",
    )
    parser.add_argument(
        "--W",
        type=int,
        default=512,
        help="image width, in pixel space",
    )
    parser.add_argument(
        "--C",
        type=int,
        default=4,
        help="latent channels",
    )
    parser.add_argument(
        "--f",
        type=int,
        default=8,
        help="downsampling factor",
    )
    parser.add_argument(
        "--n_samples",
        type=int,
        default=12, #3;这个生成12帧，相当于一个视频
        help="how many samples to produce for each given prompt. A.k.a. batch size",
    )
    parser.add_argument(
        "--n_rows",
        type=int,
        default=0,
        help="rows in the grid (default: n_samples)",
    )
    parser.add_argument(
        "--scale",
        type=float,
        default=7.5,
        help="unconditional guidance scale: eps = eps(x, empty) + scale * (eps(x, cond) - eps(x, empty))",
    )
    parser.add_argument(
        "--from-file",
        type=str,
        help="if specified, load prompts from this file",
    )
    parser.add_argument(
        "--config",
        type=str,
        default="configs/stable-diffusion/v1-inference.yaml",
        help="path to config which constructs model",
    )
    # parser.add_argument(
    #     "--ckpt",
    #     type=str,
    #     default="models/ldm/stable-diffusion-v1/model.ckpt",
    #     help="path to checkpoint of model",
    # )
    parser.add_argument(
        "--ckpt",
        type=str,
        default="/data/home/jinming/code2/stable_diffusion/models/ldm/stable-diffusion-v1/sd-v1-4.ckpt",
        help="path to checkpoint of model",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="the seed (for reproducible sampling)",
    )
    parser.add_argument(
        "--precision",
        type=str,
        help="evaluate at this precision",
        choices=["full", "autocast"],
        default="autocast"
    )
    parser.add_argument(
        "--promp_file",
        type=str,
        help="Promp file for each video_id.",
        default='/data/home/jinming/all_data/MSR-VTT/MSRVTT_splits_and_captions/msrvtt_vid2captions.json'
    )

    parser.add_argument(
        "--generation_image_path",
        type=str,
        help="The generated image path.",
        default='/data/home/jinming/all_data/MSR-VTT/MSRVTT/videos/generated_images'
    )
    opt = parser.parse_args()

    # 判断opt.generation_image_path是否存在，不存在就创建
    if not os.path.exists(opt.generation_image_path):
        os.makedirs(opt.generation_image_path)

    if opt.laion400m:
        print("Falling back to LAION 400M model...")
        opt.config = "configs/latent-diffusion/txt2img-1p4B-eval.yaml"
        # opt.ckpt = "models/ldm/text2img-large/model.ckpt"
        opt.ckpt = "/data/home/jinming/code2/new_xpool/stable_diffusion/models/ldm/stable-diffusion-v1/sd-v1-4.ckpt"
        opt.outdir = "outputs/txt2img-samples-laion400m"

    seed_everything(opt.seed)

    config = OmegaConf.load(f"{opt.config}")
    model = load_model_from_config(config, f"{opt.ckpt}")

    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    model = model.to(device)

    if opt.dpm_solver:
        sampler = DPMSolverSampler(model)
    elif opt.plms:
        sampler = PLMSSampler(model)
    else:
        sampler = DDIMSampler(model)

    os.makedirs(opt.outdir, exist_ok=True)

    print("Creating invisible watermark encoder (see https://github.com/ShieldMnt/invisible-watermark)...")
    logger.info("Creating invisible watermark encoder (see https://github.com/ShieldMnt/invisible-watermark)...")
    wm = "StableDiffusionV1"
    wm_encoder = WatermarkEncoder()
    wm_encoder.set_watermark('bytes', wm.encode('utf-8'))

    batch_size = opt.n_samples

    print(f"reading prompts from {opt.promp_file}")
    logger.info(f"reading prompts from {opt.promp_file}")
    with open(opt.promp_file, 'r') as f:
        vid2captions = json.load(f)
        vid_num = 1
        mu, sigma = create_mu_sigma_of_target_domain(class_num, path_pkl)
        for vid, captions in vid2captions.items():
            # print(vid, str(captions))
            prompt = str(captions)
            data = [batch_size * [prompt]] # ["...","...","..."]
            
            start_code = init_noise(mu, sigma) # 生成高斯噪声张量(3, 512, 512)
            start_code = None  # 原来就有的
            if opt.fixed_code: # False
                start_code = torch.randn([opt.n_samples, opt.C, opt.H // opt.f, opt.W // opt.f], device=device)

            precision_scope = autocast if opt.precision=="autocast" else nullcontext # 精度范围
            with torch.no_grad():
                with precision_scope("cuda"):
                    with model.ema_scope():
                        # for n in trange(opt.n_iter, desc="Sampling"):
                        # for prompts in tqdm(data, desc="data"):
                        for prompts in data:
                            uc = None
                            if opt.scale != 1.0:
                                uc = model.get_learned_conditioning(batch_size * [""])
                            if isinstance(prompts, tuple):
                                prompts = list(prompts)
                            # print("prompts",prompts)
                            c = model.get_learned_conditioning(prompts)
                            # print("c.shape",c.shape)
                            shape = [opt.C, opt.H // opt.f, opt.W // opt.f]
                            samples_ddim, _ = sampler.sample(S=opt.ddim_steps,
                                                            conditioning=c,
                                                            batch_size=opt.n_samples,
                                                            shape=shape,
                                                            verbose=False,
                                                            unconditional_guidance_scale=opt.scale,
                                                            unconditional_conditioning=uc,
                                                            eta=opt.ddim_eta,
                                                            x_T=start_code)

                            x_samples_ddim = model.decode_first_stage(samples_ddim)
                            x_samples_ddim = torch.clamp((x_samples_ddim + 1.0) / 2.0, min=0.0, max=1.0)
                            x_samples_ddim = x_samples_ddim.cpu().permute(0, 2, 3, 1).numpy()

                            x_checked_image, has_nsfw_concept = check_safety(x_samples_ddim)

                            x_checked_image_torch = torch.from_numpy(x_checked_image).permute(0, 3, 1, 2)

                            if not opt.skip_save:
                                image_id = 0
                                # /data/home/jinming/all_data/MSR-VTT/MSRVTT/videos/generated_images
                                for x_sample in x_checked_image_torch:
                                    if vid is not str:
                                        vid = str(vid)
                                    save_path_generation_image = os.path.join(opt.generation_image_path, vid+"_"+str(image_id)+".png")
                                    
                                    x_sample = 255. * rearrange(x_sample.cpu().numpy(), 'c h w -> h w c')
                                    img = Image.fromarray(x_sample.astype(np.uint8))
                                    img = put_watermark(img, wm_encoder)
                                    img.save(save_path_generation_image) # outputs/txt2img-samples/samples/0000#.png
                                    image_id += 1
            # if vid_num % 100 == 0:
            print(f"#######################Processed {vid_num} videos.")
            logger.info(f"#######################Processed {vid_num} videos.")
            vid_num += 1

        print(f"Your samples are ready and waiting for you here: \n{opt.generation_image_path} \n"f" \nEnjoy.")
        logger.info(f"Your samples are ready and waiting for you here: \n{opt.generation_image_path} \n"f" \nEnjoy.")

def init_noise(mu,sigma):
    # 给定均值和协方差
    mu = mu  # 假设均值向量的维度为 (512,)
    sigma = sigma  # 假设协方差矩阵的维度为 (512, 512)
    # print("原始均值：", mu)
    # print("原始协方差：", sigma)

    # 创建符合多元高斯分布的分布对象
    mvn = torch.distributions.MultivariateNormal(mu, covariance_matrix=sigma)

    # 从分布中采样以生成 (512,) 维度的噪声
    noise_sample = mvn.sample()

    # 将采样的噪声扩展为 (3, 512, 512)
    start_code = noise_sample.view(1, 512, 1).repeat(3, 1, 512)

    # print("生成的高斯噪声张量维度:", start_code.shape)
    return start_code
def create_mu_sigma_of_target_domain(class_num, path_pkl):
        # 读取 .pkl 文件############################################
        with open(path_pkl, "rb") as f:
            data = pickle.load(f)
        classnum_mu_sigma = {}
        # 打印内容
        for class_name, (mu, sigma) in data.items():
            classnum_mu_sigma[class_name] = (mu, sigma)
        str_class_num = "category_"+str(class_num)   
        target_domain_mu, target_domain_sigma = classnum_mu_sigma[str_class_num][0], classnum_mu_sigma[str_class_num][1]
        return target_domain_mu, target_domain_sigma

if __name__ == "__main__":
    class_num = 0 # 0-19
    path_pkl = "/data/home/jinming/code2/CDCMR_main_3/data/MSRVTT/Create_category_csv_file/msrvtt_CLIP_mu_sigma.pkl"
    main(class_num, path_pkl)

# import json
# save_path = '/data/home/jinming/all_data/MSR-VTT/MSRVTT_splits_and_captions/msrvtt_vid2captions.json'
# # 读取msrvtt_vid2captions.json
# with open(save_path + '/msrvtt_vid2captions.json', 'r') as f:
#     vid2captions = json.load(f)
#     for vid, captions in vid2captions.items():
#         print(vid, str(captions))

"""
使用diffusion对每个推理后的句子生成12张图像。
CUDA_VISIBLE_DEVICES=1 HF_ENDPOINT=https://hf-mirror.com python scripts/txt2img_01.py --plms 
177554
CUDA_VISIBLE_DEVICES=1 HF_ENDPOINT=https://hf-mirror.com nohup python scripts/txt2img_01.py --plms >> scripts/text_generated_image_001.log 2>&1 &

"""