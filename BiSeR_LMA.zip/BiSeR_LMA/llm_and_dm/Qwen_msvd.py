import json
from transformers import AutoModelForCausalLM, AutoTokenizer
import os
import logging


logger = logging.getLogger('my_logger')
logger.setLevel(logging.INFO)


file_handler = logging.FileHandler('Qwen_msvd.log')
file_handler.setLevel(logging.INFO) 


formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)


logger.addHandler(file_handler)

os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
device = "cuda" 
def load_json(filename):
    with open(filename, "r") as f:
        return json.load(f)

model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen1.5-MoE-A2.7B-Chat-GPTQ-Int4",
    torch_dtype="auto",
    device_map="auto"
)
model = model.to(device)
tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen1.5-MoE-A2.7B-Chat-GPTQ-Int4")

save_path = '....../split_and_captions/'

db_file = '...../captions_msvd.json'
vid2captions = {}
with open(db_file, 'r') as f:
    vid_and_caption = json.load(f)
    for vid, caption in vid_and_caption.items():
        if vid not in vid2captions:
            vid2captions[vid] = [caption]
        else:
            vid2captions[vid].append(caption)

num_vids = len(vid2captions)
num_1 = 1
logger.info(f"Start processing {num_vids} videos.")
for vid, captions in vid2captions.items():
    if num_1 == 1:
       logger.info(f"video_id: {vid}, caption:{captions}")
    prompt = "In English, summarize the following sentences into one sentence:"
    sentences = str(captions).replace('[','').replace(']','').replace('\'','').replace(',','.')
    messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": prompt+sentences}
    ]
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    model_inputs = tokenizer([text], return_tensors="pt").to(device)

    generated_ids = model.generate(
        model_inputs.input_ids,
        max_new_tokens=74 # 512
    ).to(device)

    generated_ids = [
        output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
    ]

    response = tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    vid2captions[vid] = response
    if num_1 == 1:
       logger.info(f"video_id: {vid}, caption_output:{response}")
    len_response = len(response)
    logger.info(f"video_id: {vid}, len_response:{len_response}, caption:{response}")    
    logger.info(f"Processed {num_1}/{num_vids} videos.")
    num_1 += 1

with open(save_path + '/msvd_vid2captions.json', 'w') as f:
    json.dump(vid2captions, f)
logger.info("Finished processing all videos.")


with open(save_path + '/msvd_vid2captions.json', 'r') as f:
    vid_2_caption = json.load(f)
    for vid, caption in vid_2_caption.items():
        print(vid, str(caption))



