from config.base_config import Config
from model.clip_baseline import CLIPBaseline

from model.clip_transformer import CLIPTransformer 
# from model.clip_transformer_add_T2Vattention import CLIPTransformer 
# from model.clip_transformer_add_T2Vattention_V2Tattention import CLIPTransformer 
# from model.clip_transformer_add_T2Vattention_V2Tattention_QwenDiffusion import CLIPTransformer 
# from model.clip_transformer_add_T2Vattention_V2Tattention_gru import CLIPTransformer 

class ModelFactory:
    @staticmethod
    def get_model(config: Config):
        if config.arch == 'clip_baseline':
            return CLIPBaseline(config)
        elif config.arch == 'clip_transformer':
            return CLIPTransformer(config)
        else:
            raise NotImplemented
