import torch
import torch.nn as nn
class V2T_attention(nn.Module):
    def __init__(self, config):
        super(V2T_attention, self).__init__()
        self.config = config
        self.embed_dim = config.embed_dim
        self.fusion_dim = config.embed_dim * 2
        self.fc = nn.Linear(self.fusion_dim, self.embed_dim)
        
    def forward(self, video_features, text_features):
        text_features = text_features.unsqueeze(1) 
        video_features = video_features.permute(0, 2, 1) 
        W_attention = torch.matmul(text_features, video_features) 
        W_attention = W_attention.squeeze(1) 
        max_value, max_index = torch.max(W_attention, dim=1) 
        video_features_list = []
        video_features = video_features.permute(0, 2, 1)
        for i in range(W_attention.shape[0]):
            video_features_list.append(video_features[i][max_index[i]].unsqueeze(0)) 
        video_features = torch.cat(video_features_list, 0) 
        text_features = text_features.squeeze(1) 
        
        fusion_features = torch.cat((video_features, text_features), 1) 
        text_features = self.fc(fusion_features) 
        text_features = text_features.unsqueeze(1) 
        video_features = video_features.unsqueeze(1) 

        V2T_loss = self.euclidean_distance_loss(video_features, text_features)
        text_features = text_features.squeeze(1) 

        return text_features, V2T_loss

    
    # Example usage:
    # Assuming video_features and text_features are tensors of shape 
    # loss = euclidean_distance_loss(video_features, text_features)
    def euclidean_distance_loss(self, video_features, text_features):
        """
        Compute the Euclidean distance loss between video_features and text_features.
        
        Args:
        - video_features (torch.Tensor): Tensor of shape [#, 1, 512] representing video features.
        - text_features (torch.Tensor): Tensor of shape [#, 1, 512] representing text features.
        
        Returns:
        - loss (torch.Tensor): Mean Euclidean distance loss.
        """
        # Calculate Euclidean distance between each pair of samples
        distance = torch.sqrt(torch.sum(torch.pow(video_features - text_features, 2), dim=2))
        
        # Compute mean distance across all samples
        mean_distance = torch.mean(distance)
        
        return mean_distance
    
