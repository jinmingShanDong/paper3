import torch
import torch.nn as nn

class IV_Loss(nn.Module): 
    def __init__(self, config):
        super(IV_Loss, self).__init__()
        self.fc = nn.Linear(config.num_images_generated, 1)

    def forward(self, video_features, generated_images_features):
        generated_images_features = generated_images_features.permute(0, 2, 1) 
        generated_images_features = self.fc(generated_images_features) 
        generated_images_features = generated_images_features.permute(0, 2, 1) 
        video_features = video_features.unsqueeze(1) 
        IVLoss = self.euclidean_distance_loss(video_features, generated_images_features)
        return IVLoss

    def euclidean_distance_loss(self, video_features, text_features):
        """
        Compute the Euclidean distance loss between video_features and text_features.
        
        Args:
        - video_features (torch.Tensor): Tensor of shape [#, 1, 512] representing video features.
        - text_features (torch.Tensor): Tensor of shape [#, 1, 512] representing text features.
        
        Returns:
        - loss (torch.Tensor): Mean Euclidean distance loss.
        """
        # Calculate Euclidean distance between each pair of samples
        distance = torch.sqrt(torch.sum(torch.pow(video_features - text_features, 2), dim=2))
        
        # Compute mean distance across all samples
        mean_distance = torch.mean(distance)
        
        return mean_distance