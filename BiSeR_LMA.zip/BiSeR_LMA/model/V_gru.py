import torch
import torch.nn as nn
import torch.nn.functional as F

class V_GRU(nn.Module):
    def __init__(self, config, T2V_attention):
        super(V_GRU, self).__init__()
        self.config = config
        self.embed_dim = config.embed_dim
        self.gru = nn.GRU(input_size=self.embed_dim, hidden_size=self.embed_dim, num_layers=1, batch_first=True)
        self.fc_layer = T2V_attention.fc_layer
    def forward(self, video_features, text_features):
 
        video_features, _ = self.gru(video_features) 
        clone_video_features = video_features.clone()
        clone_video_features = clone_video_features.permute(0, 2, 1) 
        text_features = text_features.unsqueeze(1) 
        clone_video_features = self.fc_layer(clone_video_features) 
        clone_video_features = clone_video_features.permute(0, 2, 1).squeeze(1) 
        loss = self.cosine_similarity_loss(clone_video_features, text_features)
        return video_features, loss
    
    def cosine_similarity_loss(self, video_features, text_features):
        """
        Compute the cosine similarity loss between video_features and text_features.
        
        Args:
        - video_features (torch.Tensor): Tensor of shape [32, embed_dim] representing video features.
        - text_features (torch.Tensor): Tensor of shape [32, embed_dim] representing text features.
        
        Returns:
        - loss (torch.Tensor): Mean cosine similarity loss.
        """
        # Compute average video feature for each sample
        video_features_flat = video_features  
        
        # Flatten the text features to make them compatible for cosine similarity calculation
        text_features_flat = text_features.squeeze(1) 
        
        # Compute cosine similarity
        cosine_similarities = F.cosine_similarity(video_features_flat, text_features_flat, dim=1)
        
        # Compute mean cosine similarity across all samples
        mean_similarity = torch.mean(cosine_similarities)
        
        # Convert cosine similarity to loss (1 - cosine_similarity) to measure dissimilarity
        loss = 1 - mean_similarity
        
        return loss

   