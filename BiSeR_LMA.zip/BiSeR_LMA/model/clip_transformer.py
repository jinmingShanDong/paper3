import sys
import torch
import torch.nn as nn
import numpy as np
import os
from config.base_config import Config


class CLIPTransformer(nn.Module):
    def __init__(self, config: Config):
        super(CLIPTransformer, self).__init__()
        self.config = config
        
        if self.config.huggingface:  
            from transformers import CLIPModel
            self.clip = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        else:
            from model.clip_model import load_clip
            self.clip = load_clip(config.clip_arch)
    
    def forward(self, data, return_all_frames=False):
        batch_size = data['video'].shape[0]
        text_data = data['text']
        video_data = data['video']
        video_data = video_data.reshape(-1, 3, self.config.input_res, self.config.input_res)
        if self.config.huggingface:
            text_features = self.clip.get_text_features(**text_data)
            video_features = self.clip.get_image_features(video_data)
        else:
            text_features = self.clip.encode_text(text_data)
            video_features = self.clip.encode_image(video_data) 
        video_features = video_features.reshape(batch_size, self.config.num_frames, -1)

        video_features = torch.mean(video_features, dim=1, keepdim=True) 
        video_features = video_features.squeeze(1) 
        
        if return_all_frames: 
            return text_features, video_features
        else: 
            return text_features, video_features, T2V_loss
