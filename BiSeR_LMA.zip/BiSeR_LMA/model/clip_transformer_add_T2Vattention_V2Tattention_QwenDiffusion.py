import sys
import torch
import torch.nn as nn
import numpy as np
import os
from config.base_config import Config
from model.V2Tattention import V2T_attention
from model.T2Vattention import T2V_attention
from model.Images_and_Video_loss import IV_Loss

class CLIPTransformer(nn.Module):
    def __init__(self, config: Config):
        super(CLIPTransformer, self).__init__()
        self.config = config
        
        if self.config.huggingface:  # False
            from transformers import CLIPModel
            self.clip = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        else:
            from model.clip_model import load_clip
            self.clip = load_clip(config.clip_arch)

        self.T2V_attention = T2V_attention(config)
        self.V2T_attention = V2T_attention(config)
        self.IV_loss = IV_Loss(config)

        self.num_images_generated = config.num_images_generated
        self.use_QwenDiffusion_geneimages = config.use_QwenDiffusion_geneimages
    
    def forward(self, data, return_all_frames=False):
        batch_size = data['video'].shape[0]
        text_data = data['text']
        video_data = data['video']
        video_data = video_data.reshape(-1, 3, self.config.input_res, self.config.input_res)

        if return_all_frames is False:
            images_data_generated = data['images_generated'].cuda()
            images_data_generated = images_data_generated.reshape(-1, 3, self.config.input_res, self.config.input_res)


        if self.config.huggingface:
            text_features = self.clip.get_text_features(**text_data)
            video_features = self.clip.get_image_features(video_data)
        else:
            text_features = self.clip.encode_text(text_data) 
            video_features = self.clip.encode_image(video_data) 
            if return_all_frames is False:
                generated_images_features = self.clip.encode_image(images_data_generated)
                generated_images_features = generated_images_features.reshape(batch_size, self.num_images_generated, -1) # [32,num_images_generated,512]

        video_features = video_features.reshape(batch_size, self.config.num_frames, -1) 

        colne_video_featues = video_features.clone()
        video_features, T2V_loss = self.T2V_attention(text_features, video_features)
        text_features, V2T_loss = self.V2T_attention(colne_video_featues, text_features)
        
        clone_video_features_1 = video_features.clone() 
        if self.use_QwenDiffusion_geneimages and (return_all_frames is False):
            IVLoss = self.IV_loss(clone_video_features_1, generated_images_features)
            loss = T2V_loss + V2T_loss + IVLoss
        else:
            loss = T2V_loss + V2T_loss

        if return_all_frames: 
            return text_features, video_features
        else:
            return text_features, video_features, loss