import sys
import torch
import torch.nn as nn
import numpy as np
import os
from config.base_config import Config
from model.T2Vattention import T2V_attention

class CLIPTransformer(nn.Module):
    def __init__(self, config: Config):
        super(CLIPTransformer, self).__init__()
        self.config = config
        
        if self.config.huggingface:  # False
            from transformers import CLIPModel
            self.clip = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
        else:
            from model.clip_model import load_clip
            self.clip = load_clip(config.clip_arch)

        self.T2V_attention = T2V_attention(config)
    
    def forward(self, data, return_all_frames=False):
        batch_size = data['video'].shape[0]
        text_data = data['text']
        video_data = data['video']
        video_data = video_data.reshape(-1, 3, self.config.input_res, self.config.input_res)
        text_features = self.clip.encode_text(text_data) 
        video_features = self.clip.encode_image(video_data)
        video_features = video_features.reshape(batch_size, self.config.num_frames, -1) 
        video_features, T2V_loss = self.T2V_attention(text_features, video_features)
        if return_all_frames:
            return text_features, video_features
        else: 
            return text_features, video_features, T2V_loss
