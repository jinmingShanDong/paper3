import torch
import torch.nn as nn
class T2V_attention(nn.Module):
    def __init__(self, config):
        super(T2V_attention, self).__init__()
        self.config = config
        self.num_frames = config.num_frames  
        self.fc = nn.Linear(self.num_frames,1)
   
    def forward(self, text_features, video_features):
        '''
        text_features: torch.Size([32, 512])
        video_features: torch.Size([32, num_frames, 512])
        '''
        text_features = text_features.unsqueeze(1) 
        video_features = video_features.permute(0, 2, 1)
        W_attention = torch.matmul(text_features, video_features)
        W_attention= W_attention.permute(0, 2, 1)
        multiply_videofeatures_by_Wattention = W_attention * video_features.permute(0, 2, 1) 
        # Plan One
        # multiply_videofeatures_by_Wattention = multiply_videofeatures_by_Wattention.permute(0, 2, 1) 
        # video_features = self.fc(multiply_videofeatures_by_Wattention) 
        # video_features = video_features.permute(0, 2, 1) 

        #Plan Two
        video_features = torch.mean(multiply_videofeatures_by_Wattention, dim=1, keepdim=True) 

        T2V_loss = self.euclidean_distance_loss(video_features, text_features)
        video_features = video_features.squeeze(1) 
        return video_features, T2V_loss
    
    def fc_layer(self, input):
        return self.fc(input)
    
    # Example usage:
    # Assuming video_features and text_features are tensors of shape [#, 1, 512]
    # loss = euclidean_distance_loss(video_features, text_features)
    def euclidean_distance_loss(self, video_features, text_features):
        """
        Compute the Euclidean distance loss between video_features and text_features.
        
        Args:
        - video_features (torch.Tensor): Tensor of shape [32, 1, 512] representing video features.
        - text_features (torch.Tensor): Tensor of shape [32, 1, 512] representing text features.
        
        Returns:
        - loss (torch.Tensor): Mean Euclidean distance loss.
        """
        # Calculate Euclidean distance between each pair of samples
        distance = torch.sqrt(torch.sum(torch.pow(video_features - text_features, 2), dim=2))
        
        # Compute mean distance across all samples
        mean_distance = torch.mean(distance)
        
        return mean_distance

    
