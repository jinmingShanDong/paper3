import numpy as np
import torch
import torch.nn.functional as F
import scipy.stats


def compute_metrics_1(lst):
    metrics = {}
    metrics["mean_ap"] = lst
    #stats = [metrics[x] for x in ("R1", "R5", "R10")]
    #metrics["geometric_mean_R1-R5-R10"] = scipy.stats.mstats.gmean(stats)
    return metrics
def calculate_map_t2v(sims):
    num_vids, max_text_per_vid, _ = sims.shape
    all_aps = []

    for vid in range(num_vids):
        for text_index in range(max_text_per_vid):
            similarity_scores = sims[vid, text_index, :]

            ground_truth = np.zeros(num_vids)
            ground_truth[vid] = 1

            sorted_indices = np.argsort(similarity_scores)[::-1]
            sorted_truth = ground_truth[sorted_indices]

            cum_sum = np.cumsum(sorted_truth)
            precisions = cum_sum / (np.arange(num_vids) + 1)
            ap = np.sum(precisions * sorted_truth) / np.sum(sorted_truth)
            all_aps.append(ap)

    mean_ap = np.mean(all_aps)
    return compute_metrics_1(mean_ap)

def calculate_map_v2t(sims):
    num_vids, max_text_per_vid, _ = sims.shape
    all_aps = []
    
    for vid in range(num_vids):
        similarity_scores = sims[:, :, vid].flatten()
        
        ground_truth = np.zeros(num_vids * max_text_per_vid)
        ground_truth[vid * max_text_per_vid:(vid + 1) * max_text_per_vid] = 1

        sorted_indices = np.argsort(similarity_scores)[::-1]
        sorted_truth = ground_truth[sorted_indices]

        cum_sum = np.cumsum(sorted_truth)
        precisions = cum_sum / (np.arange(num_vids * max_text_per_vid) + 1)
        ap = np.sum(precisions * sorted_truth) / np.sum(sorted_truth)
        all_aps.append(ap)

    mean_ap = np.mean(all_aps)
    return compute_metrics_1(mean_ap)

def sim_matrix_training(text_embeds, vid_embeds, pooling_type):
    """
    Computes the similarity matrix using pooled video frames
    
    Output
        sims: num_texts x num_vids
    """

    text_embeds = text_embeds / text_embeds.norm(dim=-1, keepdim=True) 
    vid_embeds = vid_embeds / vid_embeds.norm(dim=-1, keepdim=True) 

    if pooling_type == 'meanPool':
        sims = torch.mm(text_embeds, vid_embeds.t()) # [32,32]
        return sims
    else:
        assert False, "Not implemented pooling_type != meanPool"
    
def hamming_similarity_matrix_1(text_embeds, vid_embeds_pooled):
    num_texts = text_embeds.shape[0]
    num_vids = vid_embeds_pooled.shape[2]
    embed_dim = text_embeds.shape[2]

    similarity_matrix = torch.zeros(num_texts, num_vids)

    for i in range(num_texts):
        for j in range(num_vids):
            hamming_dist = (text_embeds[i] != vid_embeds_pooled[i, :, j]).sum()
            similarity_matrix[i, j] = 1 - hamming_dist / embed_dim
    return similarity_matrix

def sim_matrix_inference_msvd(text_embeds_per_video_id, vid_embeds_pooled_per_video_id, pooling_type):
    """
    Computes the similarity matrix using pooled video frames using all texts per video

    Output
        sims: num_vids x max_text_per_vid x num_vids
    """
    text_embeds_per_video_id = text_embeds_per_video_id / text_embeds_per_video_id.norm(dim=-1, keepdim=True) # 原来就有
    vid_embeds_pooled_per_video_id = vid_embeds_pooled_per_video_id / vid_embeds_pooled_per_video_id.norm(dim=-1, keepdim=True) #原来就有

    if pooling_type == 'meanPool':
        sims = text_embeds_per_video_id @ vid_embeds_pooled_per_video_id.t()
        return sims
    else:
        assert False, "Not implemented pooling_type != meanPool"

def sim_matrix_inference(text_embeds_per_video_id, vid_embeds_pooled_per_video_id, pooling_type):
    """
    Computes the similarity matrix using pooled video frames using all texts per video

    Output
        sims: num_vids x max_text_per_vid x num_vids
    """
    text_embeds_per_video_id = text_embeds_per_video_id / text_embeds_per_video_id.norm(dim=-1, keepdim=True) # 原来就有
    vid_embeds_pooled_per_video_id = vid_embeds_pooled_per_video_id / vid_embeds_pooled_per_video_id.norm(dim=-1, keepdim=True) #原来就有

    if pooling_type == 'meanPool':

        text_embeds_per_video_id = torch.mean(text_embeds_per_video_id, dim=1, keepdim=True) # [32,1,512]
        text_embeds_per_video_id = text_embeds_per_video_id.squeeze(1) # [32,512]
        sims = text_embeds_per_video_id @ vid_embeds_pooled_per_video_id.t()
        return sims
    else:
        assert False, "Not implemented pooling_type != meanPool"

def hamming_sim(hash_text_embeds_per_video_id, hash_vid_embeds_pooled_per_video_id):
    b1 = hash_text_embeds_per_video_id.shape[0]
    b2 = hash_vid_embeds_pooled_per_video_id.shape[0]

    hash_text_embeds_per_video_id = (hash_text_embeds_per_video_id + 1) // 2
    hash_vid_embeds_pooled_per_video_id = (hash_vid_embeds_pooled_per_video_id + 1) // 2
    sims = torch.zeros(b1, b2)
    for i in range(b1):
        for j in range(b2):
            sims[i, j] = (1 - (hash_text_embeds_per_video_id[i].int() ^ hash_vid_embeds_pooled_per_video_id[j].int())).sum()
    return sims


def hamming_similarity_matrix_2(text_embeds, vid_embeds):
    num_samples = text_embeds.size(0)
    num_vids = vid_embeds.size(2)
    embed_dim = text_embeds.size(2)
    similarity_matrix = torch.zeros(num_samples, 1, num_vids)

    for i in range(num_samples):
        for j in range(num_vids):
            hamming_dist = (text_embeds[i] == vid_embeds[i, :, j]).sum()
            similarity_matrix[i, 0, j] = hamming_dist
    return similarity_matrix

def generate_embeds_per_video_id(text_embeds, vid_embeds, all_vid_ids, pooling_type):
    text_embeds_per_video_id = {}

    for idx, v_id in enumerate(all_vid_ids):
        if v_id in text_embeds_per_video_id:
            text_embeds_per_video_id[v_id].append(text_embeds[idx])
        else:
            text_embeds_per_video_id[v_id] = [text_embeds[idx]]

    for v_id in text_embeds_per_video_id:
        text_embeds_per_video_id[v_id] = torch.stack(text_embeds_per_video_id[v_id]) 
    text_embeds_per_video_id = pad_and_stack_dict_to_tensor(text_embeds_per_video_id,
        text_embeds_per_video_id.keys(), text_embeds.shape[-1])

    if pooling_type == 'meanPool':
        vid_embeds_per_video_id = vid_embeds
        return text_embeds_per_video_id, vid_embeds_per_video_id
    else:
        assert False, "Not implemented pooling_type != meanPool"

def t2v_metrics(sims):
    stacked_sims = sims
    
    sims_sort = torch.argsort(stacked_sims, dim=-1, descending=True)
    sims_sort_2 = torch.argsort(sims_sort, dim=-1, descending=False)

    ranks = torch.flatten(torch.diagonal(sims_sort_2, dim1=0, dim2=1))
    
    valid_check = torch.flatten(torch.diagonal(sims, dim1 = 0, dim2 = 1))
    mask = ~ torch.logical_or(torch.isinf(valid_check), torch.isnan(valid_check))
    valid_ranks = ranks[mask]
    return compute_metrics(valid_ranks.numpy())

def v2t_metrics(sims):

    sims = sims.t() 
    stacked_sims = sims
    
    sims_sort = torch.argsort(stacked_sims, dim=-1, descending=True)
    sims_sort_2 = torch.argsort(sims_sort, dim=-1, descending=False)

    ranks = torch.flatten(torch.diagonal(sims_sort_2, dim1=0, dim2=1))
    
    valid_check = torch.flatten(torch.diagonal(sims, dim1 = 0, dim2 = 1))
    mask = ~ torch.logical_or(torch.isinf(valid_check), torch.isnan(valid_check))
    valid_ranks = ranks[mask]
    return compute_metrics(valid_ranks.numpy())


def compute_metrics(lst):
    metrics = {}
    metrics["R1"] = 100 * float(np.sum(lst == 0)) / len(lst)
    metrics["R5"] = 100 * float(np.sum(lst < 5)) / len(lst)
    metrics["R10"] = 100 * float(np.sum(lst < 10)) / len(lst)
    metrics["R50"] = 100 * float(np.sum(lst < 50)) / len(lst)
    metrics["R100"] = 100 * float(np.sum(lst < 100)) / len(lst)
    metrics["MedR"] = np.median(lst) + 1
    metrics["MeanR"] = np.mean(lst) + 1
    return metrics


def pad_and_stack_dict_to_tensor(input, order, d=512):
    max_length = max([input[k].shape[0] for k in input])
    
    padded_input = {k: torch.cat([input[k], torch.full((max_length - input[k].shape[0], d), 
                                                        float("-inf"), device = input[k].device)]) for k in input}
    
    padded_stacked_input = torch.stack([padded_input[k] for k in order], dim = 0) 
    return padded_stacked_input
