from config.base_config import Config
import numpy as np
import torch
from collections import defaultdict, deque
from trainer.base_trainer import BaseTrainer
from modules.metrics import sim_matrix_training, sim_matrix_inference, generate_embeds_per_video_id, sim_matrix_inference_msvd
from tqdm import tqdm
import os
import torch.nn as nn
import torch.nn.functional as F

class Trainer(BaseTrainer):
    """
    Trainer class
    Note:
        Inherited from BaseTrainer.
    """

    def __init__(self, model, loss, metrics, optimizer, config: Config, train_data_loader, 
                 valid_data_loader, tokenizer, lr_scheduler=None, writer=None):

        super().__init__(model, loss, metrics, optimizer, config, writer)
        self.train_data_loader = train_data_loader
        self.valid_data_loader = valid_data_loader
        self.lr_scheduler = lr_scheduler
        self.tokenizer = tokenizer 
        self.config = config
        self.pooling_type = config.pooling_type
        self.window_metric = defaultdict(lambda: deque(maxlen=config.eval_window_size))
        self.best_window = -1.0
        self.best_r1 = -1.0
        self.best_r5 = -1.0
        self.best_r10 = -1.0
        self.best_medr = 1000
        self.best_meanr = 1000

        self.log_save = os.path.join(config.output_dir, config.log_name)
        import logging
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
        fh = logging.FileHandler(self.log_save, mode='w')
        fh.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

        self.dataset_name = config.dataset_name
        self.msvd_linear = nn.Linear(58, 1)

        self.use_QwenDiffusion_geneimages = config.use_QwenDiffusion_geneimages

    def _train_epoch(self, epoch):
        """
        Training logic for an epoch
        :param epoch: Current training epoch.
        :return: A log that contains all information you want to save.
        """
        self.model.train()
        total_loss = 0.0
        num_steps = len(self.train_data_loader)
        eval_steps = np.linspace(0, num_steps-1, self.evals_per_epoch+1, dtype=int)[1:]

        # test use
        # val_res = self._valid_epoch_step(epoch, 1, num_steps-1) 
        # assert 0

        len_train_data_loader = len(self.train_data_loader)
        num_1 = 0
        for batch_idx, data in enumerate(self.train_data_loader):
            # then assume we must tokenize the input, e.g. its a string
            if self.tokenizer is not None:
                data['text'] = self.tokenizer(data['text'], return_tensors='pt', padding=True, truncation=True)
            if isinstance(data['text'], torch.Tensor):
                data['text'] = data['text'].to(self.device)
            else:
                data['text'] = {key: val.to(self.device) for key, val in data['text'].items()}
            
            data['video'] = data['video'].to(self.device)

            if self.use_QwenDiffusion_geneimages:
                data['images_generated'] = data['images_generated'].to(self.device)
            
            text_embeds, video_embeds, T2V_loss = self.model(data)
            output = sim_matrix_training(text_embeds, video_embeds, self.pooling_type)
            loss = self.loss(output, self.model.clip.logit_scale) 

            loss = loss + T2V_loss

            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            if self.lr_scheduler is not None:
                self.lr_scheduler.step()
            self.optimizer.zero_grad()
            torch.clamp_(self.model.clip.logit_scale.data, max=np.log(100))

            self.global_step += 1
            if self.writer is not None:
                self.writer.add_scalar('train/loss_train', loss.detach().item(), self.global_step)

            total_loss += loss.detach().item()

            if batch_idx % self.log_step == 0:
                print('Train Epoch: {} dl: {}/{} Loss: {:.6f}'.format(
                    epoch,
                    batch_idx,
                    num_steps-1,
                    loss.detach().item()))
                self.logger.info('Train Epoch: {} dl: {}/{} Loss: {:.6f}'.format( 
                    epoch,
                    batch_idx,
                    num_steps-1,
                    loss.detach().item()))
            num_1 += 1
            if batch_idx in eval_steps: 
                val_res = self._valid_epoch_step(epoch, batch_idx, num_steps-1)
                self.model.train()
                if val_res['R1-window'] > self.best_window:
                    self.best_window = val_res['R1-window']
                    self._save_checkpoint(epoch, save_best=True)
                if val_res['R1'] > self.best_r1:
                    self.best_r1 = val_res['R1']
                if val_res['R5'] > self.best_r5:
                    self.best_r5 = val_res['R5']
                if val_res['R10'] > self.best_r10:
                    self.best_r10 = val_res['R10']
                if val_res['MedR'] < self.best_medr:
                    self.best_medr = val_res['MedR']
                if val_res['MeanR'] < self.best_meanr:
                    self.best_meanr = val_res['MeanR']

                self.logger.info(" Current Best Window Average R@1 is {}".format(self.best_window))
                
                self.logger.info(" Current Best R@1 is {}".format(self.best_r1))
                self.logger.info(" Current Best R@5 is {}".format(self.best_r5))
                self.logger.info(" Current Best R@10 is {}".format(self.best_r10))
                self.logger.info(" Current Best MedR is {}".format(self.best_medr))
                self.logger.info(" Current Best MeanR is {}".format(self.best_meanr))
            
        res = {
            'loss_train':  total_loss / num_steps
        }

        return res

    def _valid_epoch_step(self, epoch, step, num_steps):
        """
        Validate at a step when training an epoch at a certain step
        :return: A log that contains information about validation
        """
        self.model.eval()
        total_val_loss = 0.0
        text_embed_arr = []
        vid_embed_arr = []
        all_vid_ids = []
        
        with torch.no_grad():
            for _, data in tqdm(enumerate(self.valid_data_loader)):
                if self.tokenizer is not None:
                    data['text'] = self.tokenizer(data['text'], return_tensors='pt', padding=True, truncation=True)
                if isinstance(data['text'], torch.Tensor):
                    data['text'] = data['text'].to(self.device)
                else:
                    data['text'] = {key: val.to(self.device) for key, val in data['text'].items()}

                data['video'] = data['video'].to(self.device)
                '''
                text_features-->text_embeds: torch.Size([32, 512])
                video_features-->video_embeds: torch.Size([32, 512])
                '''
                text_embed, vid_embed = self.model(data, return_all_frames=True)
                text_embed_arr.append(text_embed.cpu())
                vid_embed_arr.append(vid_embed.cpu())

                sims_batch = sim_matrix_training(text_embed, vid_embed, self.pooling_type)
                curr_loss = self.loss(sims_batch, self.model.clip.logit_scale)
                total_val_loss += curr_loss.item()

                for v_id in data['video_id']: 
                    all_vid_ids.append(v_id)
                
            text_embeds = torch.cat(text_embed_arr) 
            vid_embeds = torch.cat(vid_embed_arr)
            
            if self.dataset_name == 'MSVD':
                all_vid_ids_msvd_dic = {}
                for v_id in all_vid_ids:
                    if v_id not in all_vid_ids_msvd_dic:
                        all_vid_ids_msvd_dic[v_id] = 1
                    else:
                        all_vid_ids_msvd_dic[v_id] += 1
                all_vid_ids_msvd = all_vid_ids_msvd_dic.keys()

                text_embeds_list = []
                vid_embeds_list = []
                array_all_vid_ids = np.array(all_vid_ids)
                
                for vid_ids in all_vid_ids_msvd:
                    indexes = np.where(array_all_vid_ids == vid_ids)[0] 
                    indexes = list(indexes)
                    index = np.random.choice(indexes)
                    text_embeds_list.append(text_embeds[index])
                    vid_embeds_list.append(vid_embeds[index])
                all_vid_ids = all_vid_ids_msvd
                text_embeds = torch.stack(text_embeds_list)
                vid_embeds = torch.stack(vid_embeds_list)

            vid_embeds_per_video_id = {}
            for idx, v_id in enumerate(all_vid_ids):
                if v_id not in vid_embeds_per_video_id:
                    vid_embeds_per_video_id[v_id] = vid_embeds[idx]
            vid_embeds = torch.stack([vid_embeds_per_video_id[v_id] for v_id in vid_embeds_per_video_id]) 

            text_embeds_per_video_id, vid_embeds_per_video_id = generate_embeds_per_video_id(text_embeds, 
                    vid_embeds, all_vid_ids, self.pooling_type)
       

            sims = sim_matrix_inference(text_embeds_per_video_id, vid_embeds_per_video_id, self.pooling_type)

            total_val_loss = total_val_loss / len(self.valid_data_loader)
            metrics = self.metrics
            res = metrics(sims)
            if self.config.metric == 't2v' or self.config.metric == 'v2t':
                for m in res:
                    self.window_metric[m].append(res[m])

                for m in self.window_metric:
                    res[m + "-window"] = np.mean(self.window_metric[m])

                self.logger.info(f"-----Val Epoch: {epoch}, dl: {step}/{num_steps}-----\n" +
                        f"R@1: {res['R1']} (window: {res['R1-window']})\n" + 
                        f"R@5: {res['R5']} (window: {res['R5-window']})\n" + 
                        f"R@10: {res['R10']} (window: {res['R10-window']})\n" +
                        f"MedR: {res['MedR']} (window: {res['MedR-window']})\n" +
                        f"MeanR: {res['MeanR']} (window: {res['MeanR-window']})\n" +
                        f"Loss: {total_val_loss}")
                res['loss_val'] =  total_val_loss
            else:
                self.logger.info(f"-----Val Epoch: {epoch}, dl: {step}/{num_steps}-----\n" +
                        f"mAP: {res['mean_ap']}\n" + 
                        f"Loss: {total_val_loss}")

            if self.writer is not None:
                for m in res:
                    self.writer.add_scalar(f'val/{m}', res[m], self.global_step)

            return res
    




