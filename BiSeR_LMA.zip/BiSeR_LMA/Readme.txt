1. texts to text:
BiSeR_LMA/llm_and_dm/Qwen_***.py

2. text to video fames:
BiSeR_LMA/llm_and_dm/scripts/txt2img_***.py

3. training retrieval model and test model:
BiSeR_LMA/train.py
